﻿function ViewModel(sentMessageLogger) {
    this.DEFAULT_TEMPERATURE = 65;
    this.DEFAULT_HUMIDITY = 40;
    this.currentTemperature = this.DEFAULT_TEMPERATURE;
    this.currentHumidity = this.DEFAULT_HUMIDITY;

    this.maxTemperature = 120;
    this.minTemperature = 10;

    this.maxHumidity = 100;
    this.minHumidity = 0;

    this.sentMessageLogger = sentMessageLogger;
    this.loggerContexts = {};
    this.currentConnection = null;
};

ViewModel.prototype.getTemperature = function () {
    return this.currentTemperature;
};

ViewModel.prototype.getHumidity = function () {
    return this.currentHumidity;
};

ViewModel.prototype.getConnection = function () {
    return this.currentConnection;
};

ViewModel.prototype._truncateValue = function (requestedValue, minValue, maxValue) {
    return Math.max(minValue, Math.min(requestedValue, maxValue));
}

ViewModel.prototype.truncateTemperature = function (requestedValue) {
    return this._truncateValue(requestedValue, this.minTemperature, this.maxTemperature);
}

ViewModel.prototype.setTemperature = function (requestedValue) {
    this.currentTemperature = this.truncateTemperature(requestedValue);
};

ViewModel.prototype.truncateHumidity = function (requestedValue) {
    return this._truncateValue(requestedValue, this.minHumidity, this.maxHumidity);
}

ViewModel.prototype.setHumidity = function (requestedValue) {
    this.currentHumidity = this.truncateHumidity(requestedValue);
};

ViewModel.prototype.setConnection = function (connection) {
    this.currentConnection = connection;
};

// Sets a new device id, and switches the logger context in order to show the history of messages 
// sent to the device represented by this id.
ViewModel.prototype.setDeviceId = function (deviceId) {
    // Save the old logger context.
    var oldDeviceId = this.currentConnection.getDeviceId();
    if (oldDeviceId) {
        this.loggerContexts[oldDeviceId].save();
    }
    // Set the new deviceId.
    this.currentConnection.setDeviceId(deviceId);
    if (deviceId) {
        // Create a new logger context if it's the first time this id is in use.
        if (this.loggerContexts[deviceId] === undefined) {
            this.loggerContexts[deviceId] = new MessageDisplayContext();
        }
        // Set the logger context for this device.
        this.sentMessageLogger.setContext(this.loggerContexts[deviceId]);
    }
};

function generateGuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};

var DEVICE_REQUEST = {
    SEND_EVENT: "SendEvent",
    POLL_COMMANDS: "GetCommands",
    START_RECEIVING: "StartReceivingCommands",
    STOP_RECEIVING: "StopReceivingCommands",
};

ViewModel.prototype.isDeviceRequest = function (request) {
    for (var property in DEVICE_REQUEST) {
        if (DEVICE_REQUEST.hasOwnProperty(property) && DEVICE_REQUEST[property] === request) {
            return true;
        }
    }
    return false;
};

var HUB_REQUEST = {
    SEARCH_DEVICES: "SearchForDevices",
    GET_DEVICES: "GetDevices",
    TEST_CONNECTION: "TestConnection",
};

var REQUEST = {
    DEVICE: DEVICE_REQUEST,
    HUB: HUB_REQUEST,
};

ViewModel.prototype.testConnection = function (onSuccess, onFailure, onConnectionError) {
    var _this = this;
    this._makePostRequest(REQUEST.HUB.TEST_CONNECTION, {}, function (response) {
        _this._processResponse(response, function (response) {
            if (response.TestConnectionResult) {
                var connectionWorking = JSON.parse(response.TestConnectionResult);
                if (connectionWorking) {
                    onSuccess();
                } else {
                    onFailure();
                }
            } else {
                onFailure();
            }
        });
    }, {}, onConnectionError);
};

ViewModel.prototype.getDevices = function (onSuccess) {
    var _this = this;
    this._makePostRequest(REQUEST.HUB.SEARCH_DEVICES, {}, function () {
        _this._requestDevices(100, onSuccess);
    });
};

ViewModel.prototype._requestDevices = function (retryBackoff, onSuccess) {
    var _this = this;
    this._makePostRequest(REQUEST.HUB.GET_DEVICES, {}, function (response) {
        _this._processResponse(response, function (response) {
            _this._executeDevicesResponse(response, retryBackoff, onSuccess);
        });
    });
};

ViewModel.prototype._executeDevicesResponse = function (response, retryBackoff, onSuccess) {
    if (response.GetDevicesResult != "") {
        var response = JSON.parse(response.GetDevicesResult);
        if (response.status === "SEARCHING") {
            // Retry the call
            var _this = this;
            setTimeout(function () {
                // Applying exponential backoff to the next request.
                _this._requestDevices(retryBackoff * 2, onSuccess);
            }, retryBackoff); // Wait to give time for the server's async search to complete.
        } else {
            console.log(response);
            onSuccess(response);
        }
    }
};

ViewModel.prototype.startReceivingCommands = function () {
    var paramsData = {};
    this._makePostRequest(REQUEST.DEVICE.START_RECEIVING, paramsData);
};

ViewModel.prototype.stopReceivingCommands = function () {
    var paramsData = {};
    this._makePostRequest(REQUEST.DEVICE.STOP_RECEIVING, paramsData);
};

ViewModel.prototype.pollForCommands = function (onSuccess, onComplete, onError) {
    var paramsData = {};
    var _this = this;
    this._makePostRequest(REQUEST.DEVICE.POLL_COMMANDS, paramsData, function (data) {
        _this._processResponse(data, function (data) {
            if (data.GetCommandsResult != "") {
                var receivedCommandsArray = _this._parseJSONCommand(data.GetCommandsResult, onError);
                console.log("Received: " + receivedCommandsArray.length + " commands");
                for (var i = 0; i < receivedCommandsArray.length; i++) {
                    var commandObject = _this._parseJSONCommand(receivedCommandsArray[i], onError);
                    console.log(commandObject);
                    onSuccess(commandObject.CommandName, commandObject.Parameters);
                }
            }
        });
    }, onComplete);
};

ViewModel.prototype._parseJSONCommand = function (value, errorHandler) {
    try {
        return JSON.parse(value);
    } catch (err) {
        errorHandler("RECEIVED INVALID JSON");
        console.log("invalid json: '" + value + "'");
        throw err;
    }
};

ViewModel.prototype.sendIoTData = function () {
    var telemetryData = {};
    var eventData = {};
    var paramsData = {};

    telemetryData.DeviceId = this.getConnection().getDeviceId();
    telemetryData.DeviceSerialNumber = "12345";
    telemetryData.EventToken = generateGuid(); //"C5A4680A-3EB6-4a86-B369-E738B3CC66EA";
    telemetryData.Temperature = this.currentTemperature;
    telemetryData.Humidity = this.currentHumidity;

    eventData.TelemetryData = telemetryData;

    paramsData.eventData = eventData;


    this.sentMessageLogger.log("CURRENT STATUS -> Temperature: " + this.currentTemperature + " Humidity: "
        + this.currentHumidity);
    this._makePostRequest(REQUEST.DEVICE.SEND_EVENT, paramsData);
};

ViewModel.prototype._makePostRequest = function (request, params, onSuccess, onComplete, onError) {
    this.currentConnection.addParams(request, params);

    var jsonEntity = window.JSON.stringify(params);

    $.ajax({
        type: "POST",
        url: "IoTGatewayService.svc/" + request,
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        data: jsonEntity,
        beforeSend: function (xhr) {
            //Specifying this header ensures that the results will be returned as JSON.             
            xhr.setRequestHeader("Accept", "application/json");
        },
        success: onSuccess,
        error: onError,
        complete: onComplete,
        timeout: 30000
    });
};

ViewModel.prototype._processResponse = function (serverResponse, processingFunction) {
    try {
        processingFunction(serverResponse);
    }
    catch (err) {
        console.log("Error while processing:")
        console.log(serverResponse);
        console.log(err.message);
    }
}