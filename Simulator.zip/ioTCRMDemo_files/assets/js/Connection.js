﻿function Connection(host, policyName, key) {
    this.host = host;
    this.policyName = policyName;
    this.key = key;
    this.deviceId = "";
}

var defaultConnectionParams = {

    getHost: function () {
        var cookieHost = cookieManager.getCookie(cookieManager.HOST);
        var querystringHost = queryString.getParameter("host");
        if (cookieHost) {
            return cookieHost;
        } else if (querystringHost) {
            return querystringHost;
        } else {
            return "";
        }
    },

    getPolicyName: function () {
        var cookiePolicy = cookieManager.getCookie(cookieManager.POLICY);
        var querystringPolicy = queryString.getParameter("policyName");
        if (cookiePolicy) {
            return cookiePolicy;
        } else if (querystringPolicy) {
            return querystringPolicy;
        } else {
            return "iothubowner";
        }
    },

    getKey: function () {
        var key = cookieManager.getCookie(cookieManager.KEY);
        if (key) {
            return key;
        } else {
            return queryString.getParameter("key");
        }
    },
}

var DefaultConnection = new Connection(defaultConnectionParams.getHost(), defaultConnectionParams.getPolicyName(),
    defaultConnectionParams.getKey());

Connection.prototype.getHost = function () {
    return this.host;
};

Connection.prototype.getPolicyName = function () {
    return this.policyName;
};

Connection.prototype.getKey = function () {
    return this.key;
};

Connection.prototype.getDeviceId = function () {
    return this.deviceId;
};

Connection.prototype.setDeviceId = function (id) {
    this.deviceId = id;
};

Connection.prototype.addParams = function (request, params) {
    var hub = {};
    var hostSuffix = ".azure-devices.net";
    hub.Host = this.getHost().indexOf(hostSuffix) !== -1 ? this.getHost() : this.getHost() + hostSuffix; // Using indexOf since endsWith is not available in IE.
    hub.Key = this.getKey();
    hub.PolicyName = this.getPolicyName();
    if (viewModel.isDeviceRequest(request)) {
        params.connection = { Hub: hub, DeviceId: this.getDeviceId() };
    } else {
        params.connection = hub;
    }
};
