﻿var view = {

    pushingRate: 10000, // Sending the current status every 10 seconds.
    temperatureUnit: "°F",
    humidityUnit: "%",
    upSimulationDelta: 10,
    downSimulationDelta: 10,

    init: function (receivedCommandLogger) {
        this.temperature = $("#temperature");
        this.humidity = $("#humidity");
        this.timerId = null;
        this.receivedCommandLogger = receivedCommandLogger;
        this.deviceContexts = {};
        this.navLinkReboot = $('#rebootNavLink');

        this.initTemperature();
        this.initHumidity();

        var _this = this;
        this.temperature.on("change", function () {
            var value = _this.temperature.val().replace(_this.temperatureUnit, '');
            viewModel.setTemperature(parseInt(value));
        });

        this.humidity.on("change", function () {
            var value = _this.humidity.val().replace(_this.humidityUnit, '');
            viewModel.setHumidity(parseInt(value));
        });

        $("#tempLabel").on("click", this.simulateUp.bind(this));
        $("#humidityLabel").on("click", this.simulateDown.bind(this));
        $("#fetchIdsButton").on("click", this.populateDeviceList.bind(this));
        $("#idSelect").on("change", this.refreshDeviceId.bind(this));
        $("#rebootNavButton").on("click", this.rebootAnimation.bind(this));

        $(window).resize(function () {
            // Trigger change to reset value and render
            _this.humidity.trigger("change");
            _this.temperature.trigger("change");
        });

        this.temperature.on('click', this.killSimulation.bind(this));
        this.humidity.on('click', this.killSimulation.bind(this));

        this.setHumidity(viewModel.getHumidity());
        this.setTemperature(viewModel.getTemperature());
        $("#greenDot").hide();

        // Captures right click
        window.oncontextmenu = this.toggleDeviceEvents.bind(this);

        // Stop polling when the simulator is closed.
        window.onbeforeunload = this.clearDeviceId.bind(this);
    },

    refreshDeviceId: function () {
        var id = $("#idSelect").val();
        // Stop sending events for the old id.
        this.stopDeviceEvents();
        // Stop receiving commands for the old id.
        this.killPolling();

        viewModel.setDeviceId(id);
        this.switchDeviceContext(this.deviceId, id);
        this.deviceId = id;

        if (id) {
            // Start sending events for the new id.
            this.startDeviceEvents();
            // Sets the command polling to start in 5 seconds
            this.startPolling(true);
        }
    },

    switchDeviceContext: function (oldDeviceId, newDeviceId) {
        this._saveContext(oldDeviceId);
        if (newDeviceId) {
            this._createDefaultContext(newDeviceId);
            this._loadContext(newDeviceId);
        }
    },

    _saveContext: function (deviceId) {
        if (deviceId && this.deviceContexts[deviceId]) {
            this.deviceContexts[deviceId].temperature = viewModel.getTemperature();
            this.deviceContexts[deviceId].humidity = viewModel.getHumidity();
            this.deviceContexts[deviceId].loggerContext.save();
        }
    },

    _createDefaultContext: function (deviceId) {
        // If it's the first time loading this device
        if (deviceId && this.deviceContexts[deviceId] === undefined) {
            this.deviceContexts[deviceId] = {
                loggerContext: new MessageDisplayContext(),
                temperature: viewModel.DEFAULT_TEMPERATURE,
                humidity: viewModel.DEFAULT_HUMIDITY
            };
        }
    },

    _loadContext: function (deviceId) {
        var context = this.deviceContexts[deviceId];
        this.setTemperature(context.temperature);
        this.setHumidity(context.humidity);
        this.receivedCommandLogger.setContext(context.loggerContext);
    },

    clearDeviceId: function () {
        $("#idSelect").val("");
        this.switchDeviceContext(this.deviceId, null);
        this.deviceId = null;
        this.refreshDeviceId();
    },

    connectionFailed: function () {
        this._toggleDeviceButtons(true);
        $("#idSelect").empty();
        // Clearing all the actions related to the previously selected device id
        this.clearDeviceId();
    },

    connectionWasSet: function () {
        this._toggleDeviceButtons(false);
        this.populateDeviceList();
    },

    populateDeviceList: function () {
        // Clearing all the actions related to the previously selected device id
        this.clearDeviceId();
        this._toggleDeviceButtons(true);
        var _this = this;
        viewModel.getDevices(function (deviceArray) {
            $("#idSelect").empty();
            $("#idSelect").append("<option disabled selected value> Select a device </option>");
            deviceArray.sort();
            deviceArray.forEach(function (device) {
                var option = "<option value='" + device + "'>" + device + "</option>";
                $("#idSelect").append(option);
            });
            _this._toggleDeviceButtons(false);
        });
    },

    _toggleDeviceButtons: function (isDisabled) {
        $("#fetchIdsButton").prop("disabled", isDisabled);
        $("#idSelect").prop("disabled", isDisabled);
    },

    startDeviceEvents: function () {
        if (viewModel.getConnection().getDeviceId()) {
            this.timerId = setInterval(viewModel.sendIoTData.bind(viewModel), this.pushingRate);
            $("#redDot").hide();
            $("#greenDot").show();
        }
    },

    stopDeviceEvents: function () {
        if (this.timerId) {
            clearInterval(this.timerId);
            this.timerId = null;
            $("#redDot").show();
            $("#greenDot").hide();
        }
    },

    toggleDeviceEvents: function() {
        if (this.timerId) {
            this.stopDeviceEvents();
        } else if (viewModel.getConnection() && viewModel.getConnection().getDeviceId()) {
            view.startDeviceEvents();
        }
        return false;
    },

    // Polling Methods

    // startPolling will make the setup for the device to start receiving commands from the IoTHub
    //      wait: boolean representing if we want to make the standard wait done before polling for the first time or 
    //            just use the standard waiting time between iterations.
    startPolling: function (wait) {
        if (viewModel.getConnection().getDeviceId()) {
            viewModel.startReceivingCommands();
            var newPoller;
            if (wait) {
                newPoller = new StartCommandPoller(viewModel);
            } else {
                newPoller = new IterationCommandPoller(viewModel);
            }
            this.setCurrentPoller(newPoller);
        }
    },

    setCurrentPoller: function (newPoller) {
        if (this.currentPoller) {
            this.currentPoller.kill();
        }
        this.currentPoller = newPoller;
    },

    killPolling: function () {
        this.setCurrentPoller(null);
        viewModel.stopReceivingCommands();
    },

    onCommand: function (commandName, parameters) {
        switch (commandName) {
            case "Set Values":
				if (parameters.Reading) {
					this.setValues(parameters.Reading.Temperature, parameters.Reading.Humidity);
                }
                break;
            case "Notification":
                if (parameters.Message) {
                    this.receivedCommandLogger.log(parameters.Message);
                }
                break;
            case "Reset Thermostat":
                this.receivedCommandLogger.log("REBOOT");
                this.rebootAnimation();
                break;
            case "Desired properties changed":
                this.receivedCommandLogger.log("Desired properties changed from the DeviceTwin");
                this.setValues(parameters.Temperature, parameters.Humidity);
                break;
            default:
                this.receivedCommandLogger.log("UNRECOGNIZED COMMAND: " + commandName);
                break;
        }
    },

    setValues: function (temperature, humidity) {
        // Rounding the values, we want the thermostat to work with integers.
        var roundedTemperature = Math.round(parseFloat(temperature));
        var roundedHumidity = Math.round(parseFloat(humidity));

        // Truncating the values to fit the range of the thermostat.
        var newTemperature = viewModel.truncateTemperature(roundedTemperature);
        var newHumidity = viewModel.truncateHumidity(roundedHumidity);
        this.receivedCommandLogger.log("SETTING VALUES -> Temperature: " + newTemperature
            + " Humidity: " + newHumidity);
        this.setSimulation(newTemperature, newHumidity);
    },

    onError: function (errorMessage) {
        this.receivedCommandLogger.log(errorMessage);
    },
    
    rebootAnimation: function () {
        if (!this.isRebooting) {
            this.isRebooting = true;
            // Stop sending the status and receiving commands while rebooting.
            this.stopDeviceEvents();
            this.killPolling();

            $('#rebootProgressBar').attr('aria-valuenow', "0%").css('width', "0%");
            $('#rebootModal').modal('show');
            $('#rebootModelSection').html('Rebooting...<span class="glyphicon glyphicon-wrench wrenching"></span>');
            
            var _this = this;
            var i = 0;

            _this.setTemperature(viewModel.minTemperature);
            _this.setHumidity(viewModel.minHumidity);
            _this.setSimulation(viewModel.DEFAULT_TEMPERATURE, viewModel.DEFAULT_HUMIDITY);
            var timer = setInterval(function () {
                if (i <= 100) {
                    var newValue = i + "%";
                    $('#rebootProgressBar').css('width', newValue);
                    if (i % 10 == 0) {
                        $('#rebootProgressBar').attr({'aria-valuenow': newValue});
                    }
                    if (i == 100) {
                        $('#rebootModelSection').attr({ 'aria-live': 'assertive', 'role': 'alert' });
                        $('#rebootModelSection').text('Rebooting Completed');
                    }
                    i += 1;
                } else {
                    // Kill this function   
                    clearInterval(timer);
                    $('#rebootModal').modal('hide');
                    // Start sending the status and receiving commands again.
                    _this.startDeviceEvents();
                    _this.startPolling(false);

                    _this.isRebooting = false;
                    _this.navLinkReboot.focus();
                }
            }, 100);
        }
    },

    // Setters

    setTemperature: function (value) {
        if (!isNaN(value)) {
            this.temperature.val(value).trigger('change');
        }
    },

    setHumidity: function (value) {
        if (!isNaN(value)) {
            this.humidity.val(value).trigger('change');
        }
    },

    // Simulation Methods

    simulateUp: function () {
        var newTemp = viewModel.getTemperature() + this.upSimulationDelta;
        var newHum = viewModel.getHumidity() + this.upSimulationDelta;
        this.setSimulation(newTemp, newHum);
    },

    simulateDown: function () {
        var newTemp = viewModel.getTemperature() - this.downSimulationDelta;
        var newHum = viewModel.getHumidity() - this.downSimulationDelta;
        this.setSimulation(newTemp, newHum);
    },

    setSimulation: function (targetTemperature, targetHumidity) {
        this.killSimulation();
        var param = [{ get: viewModel.getTemperature.bind(viewModel), set: this.setTemperature.bind(this), target: targetTemperature },
                       { get: viewModel.getHumidity.bind(viewModel), set: this.setHumidity.bind(this), target: targetHumidity }];
        this._simulation = new Simulation(param);
        this._simulation.start();
    },

    killSimulation: function () {
        if (this._simulation) {
            this._simulation.kill();
            this._simulation = null;
        }
    },

    // Knob initialization

    initTemperature: function () {
        var _this = this;
        this.temperature.knob({
            angleArc: 180,
            angleOffset: -90,
            'aria-label': "Temperature Dial",
            'min': viewModel.minTemperature,
            'max': viewModel.maxTemperature,
            'width': "100%",
            'height': "100%",
            'fgColor': '#66CC66',
            'format': function (value) {
                if (isNaN(value)) {
                    return "";
                }
                viewModel.setTemperature(value);
                return value + _this.temperatureUnit;
            }
        });
    },

    initHumidity: function () {
        var _this = this;
        this.humidity.knob({
            angleArc: 180,
            angleOffset: -90,
            'aria-label': "Humidity Dial",
            'min': viewModel.minHumidity,
            'max': viewModel.maxHumidity,
            'width' : "100%",
            'height': "100%",
            'format': function (value) {
                if (isNaN(value)) {
                    return "";
                }
                viewModel.setHumidity(value);
                return value + _this.humidityUnit;
            }
        });
    },
};
