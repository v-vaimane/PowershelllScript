﻿function Simulation(fieldsArray) {
    this.fieldsArray = fieldsArray;
    this.interval = 200; // Trigger every 0.2s
}

Simulation.prototype.start = function (delta, interval) {
    if (delta) {
        this.delta = delta;
    } else {
        this.delta = 1;
    }
    if (interval) {
        this.interval = interval;
    }
    this.timerId = setInterval(this.iteration.bind(this), this.interval);
};

Simulation.prototype.iteration = function () {
    var hasChanges = false;
    var _this = this;
    this.fieldsArray.forEach(function (elem) {
        var currentValue = elem.get();
        if (currentValue !== elem.target) {
            hasChanges = true;
            var factor = currentValue > elem.target ? -1 : 1;
            elem.set(currentValue + factor * _this.delta);
        }
    });
    if (!hasChanges) {
        this.kill();
    }
};

Simulation.prototype.kill = function () {
    clearInterval(this.timerId);
};