﻿function MessageDisplay(messageDivId) {
    this.messageHistoryElem = $("#" + messageDivId);
    this.context = new MessageDisplayContext();
    this.typingTimeout = null;
}

// Sets a new logger context to manage the messages shown in this display.
MessageDisplay.prototype.setContext = function (newContext) {
    clearTimeout(this.typingTimeout);
    this.context = newContext;
    this._refreshUI();
};

// Logs a message on this display. 
// - If there are no messages being logged, it will start typing it.
// - If there is a message already being logged, it will be queued.
MessageDisplay.prototype.log = function (message) {
    this.context.logMessage(message);
    if (!this.isLogging) {
        // There is no typing on effect, so this will create a thread that will 
        // type non-stop until the context answers that there is nothing left to type.
        this._log();
    }
};

MessageDisplay.prototype._log = function () {
    this.isLogging = true;
    this._refreshUI();
};

MessageDisplay.prototype._refreshUI = function () {
    this.messageHistoryElem.text(this.context.getText());
    this._type();
};

// Recursive function that will auto-invoke every 50 millis to make the typing effect.
// It will tell the context to type a character, and then refresh the UI. Once there 
// is nothing left to type, just turn off the isLogging flag and return.
MessageDisplay.prototype._type = function () {
    this.context.type();
    this.messageHistoryElem.text(this.context.getText());
    if (this.context.hasTypingFinished()) {
        this.isLogging = false;
    } else {
        setTimeout(this._type.bind(this), 50);
    }
};