﻿var queryString = {

    // Gets the value of the query string parameter paired to the key provided. 
    // If the key doesn't exist, or the value is empty, it will return "".
    // For example, for this url: www.example.org?foo=this+is+a+str&bar=this%20is+a+%2b+sign&baz=&qux&else
    // getParameter("bar") -> "this is a + sign"
    // getParameter("foo") -> "this is a str" 
    // getParameter("baz") -> ""
    // getParameter("qux") -> ""
    // getParameter("something") -> ""
    getParameter: function (name) {
        var param = name.replace(/[\[\]]/g, "\\$&");
        var url = window.location.href;
        // Create the regex that will get the parameter from the URL. It will match a valid start (? for the beggining 
        // of the queryString, & if it is after another parameter), the parameter name provided, and then any special 
        // character that may mark the end of the parameter.
        var regex = new RegExp("[?&]" + param + "(=([^&#]*)|&|#|$)");
        var results = regex.exec(url);
        if (results && results[2]) {
            // Get the third value, as the answer will have matched: [&name=value, name=value, value].
            var encodedParameter = results[2];
            // decodeURIComponent will decode all encoded query string characters, except for + signs. 
            // + is a valid encoding for spaces, so we will decode it manually.
            // (+ signs are valid if encoded as %2B, so we need to replace them BEFORE calling decodeURIComponent)
            return decodeURIComponent(encodedParameter.replace(/\+/g, " "));
        } else {
            return '';
        }
    }
};
